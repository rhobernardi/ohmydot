# Marwaita
GTK theme for Cinnamon desktop

## Requirments

### GTK+ 3.20 or later

### GTK+ 4.0 or later
